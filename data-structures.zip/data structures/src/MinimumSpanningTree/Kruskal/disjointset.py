from MinimumSpanningTree.Kruskal.node import Node


class DisJointSet(object):
    def __init__(self, vertexList):
        self.vertexList = vertexList
        self.rootNode = []
        self.nodeCount = 0
        self.setCount= 0
        self.makeSets(vertexList)
        
        
    def makeSets(self, vertexList):
        for vx in vertexList :
            self.makeSet(vx)
            
    def makeSet(self, vertex):
        node = Node(0, len(self.rootNode), None)
        vertex.parentNode = node
        self.rootNode.append(node)
        self.setCount+= 1
        self.nodeCount+=1
    
    def find(self, node):
        currentNode = node
        while currentNode.parentNode is not None:
            currentNode = currentNode.parentNode
            
        root = currentNode
        currentNode = node
        
        while currentNode is not root:
            temp = currentNode.parentNode
            currentNode.parentNode = root
            currentNode = temp
    
        return  root.nodeId
    
    def union(self, node1, node2):
        index1 = self.find(node1)
        index2 = self.find(node2)
        
        if index1 == index2:
            return;
        
        root1 = self.rootNode[index1]
        root2 = self.rootNode[index2]
        
        
        
        if root1.height < root2.height:
            root1.parentNode = root2
        elif root1.height > root2.height:
            root2.parentNode = root1
        else :
            root2.parentNode = root1
            root1.height+= 1
            
        
        self.setCount-= 1
        
        
        