
class Node(object):
    def __init__(self, data):
        self.data = data
        self.next = None
        
    def removeNode(self, data, prev):
        if self.data == data:
            prev.next = self.next
            del self.data
            del self.next
        else:
            self.next.removeNode(data,self)    