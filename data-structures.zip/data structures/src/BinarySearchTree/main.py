from BinarySearchTree.bst import BST
from BinarySearchTree.Node import Node

bst = BST()

bst.insert(12)

bst.insert(-123)

bst.insert(124)

bst.insert(26)

bst.insert(129)
bst.traverseListInOrder()

print(bst.getMax())

print(bst.getMin())
bst.remove(26)
bst.remove(12)
bst.traverseListInOrder()