from ShortestPathProblem.DijkstraAlgorithm.vertex import Vertex
from ShortestPathProblem.DijkstraAlgorithm.edge import Edge
from ShortestPathProblem.DijkstraAlgorithm.djt import Dijkstra


node1 = Vertex("A")
node2 = Vertex("B")
node3 = Vertex("C")
node4 = Vertex("D")


edge1 = Edge(1, node1, node2)
edge2 = Edge(1, node2, node3)
edge3 = Edge(0.2, node1, node3)
edge4 = Edge(0.1, node1, node4)

node1.adjacentList.append(edge1)
node1.adjacentList.append(edge2)
node2.adjacentList.append(edge3)
node1.adjacentList.append(edge4)

vertexList =[node1, node2, node3, node4]

djt = Dijkstra()
djt.calculateShortestPath(vertexList, node1)
djt.getShortestDisatnce(node4)
