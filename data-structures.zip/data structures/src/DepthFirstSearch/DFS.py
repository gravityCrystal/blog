def dfs(node):
    node.visited =True
    print(" ->", node.name)    
    for n in node.adjacentList:
        if not n.visited:
            dfs(n)